import colorama


def get_colorama_version():
    return colorama.__version__
