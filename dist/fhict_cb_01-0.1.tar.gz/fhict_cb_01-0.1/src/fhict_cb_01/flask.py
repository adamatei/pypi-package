import flask


def get_flask_version():
    return flask.__version__
